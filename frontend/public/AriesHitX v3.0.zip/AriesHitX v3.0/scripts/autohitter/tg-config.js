// ===================================
// Telegram Bot & Auth Config
// Set your backend URL here – users never see this. All TG flows use this.
// ===================================

const TGConfig = {
  BOT_URL: 'https://api.mikeyyfrr.me',  // Python backend - change to your production URL when deploying
  BOT_USERNAME: 'AriesxHitBot',      // Your bot username (without @) for Get Token link
  ENDPOINTS: {
    SEND_OTP: '/api/tg/send-otp',
    VERIFY: '/api/tg/verify',
    SEE_PROXY: '/api/tg/see-proxy',
    ADD_PROXY: '/api/tg/add-proxy',
    CHECK_PROXY: '/api/tg/check-proxy',
    DELETE_PROXY: '/api/tg/delete-proxy',
    DELETE_ALL_PROXIES: '/api/tg/delete-all-proxies',
    CO: '/api/tg/co',
    NOTIFY_HIT: '/api/tg/notify-hit',
  },
  getUrl(path) {
    return this.BOT_URL + path;
  },
};
